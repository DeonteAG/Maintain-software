package com.breakmaintain.gameInterface;

// import files needed in order for the game to run

import com.breakmaintain.gameBall.Ball;
import com.breakmaintain.gameBricks.Brick;
import com.breakmaintain.gameDebug.DebugConsole;
import javafx.application.Platform;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.font.FontRenderContext;


/**
 * This class is for the game board which extends the J component and implements listeners
 *
 * @author Deonte Allen-Gooden-modified
 */
public class GameBoard extends JComponent implements KeyListener,MouseListener,MouseMotionListener {

    /**
     * The constant BG_COLOR.
     */
    public static Color BG_COLOR = Color.BLACK;

    /**
     * string for the continue button
     */
    private static final String CONTINUE = "Continue";

    /**
     * string for the restart button
     */
    private static final String RESTART = "Restart";

    /**
     * string for the exit button
     */
    private static final String EXIT = "Exit";

    /**
     * string for the pause menu button
     */
    private static final String PAUSE = "Pause Menu";

    /**
     * integer for the text size set to 30
     */
    private static final int TEXT_SIZE = 30;

    /**
     * set the menu colour
     */
    private static final Color MENU_COLOR = new Color(0,255,0);

    /**
     * set the int for the width size at 600
     */
    private static final int DEF_WIDTH = 600;

    /**
     * set the int for the height size at 450
     */
    private static final int DEF_HEIGHT = 450;

    /**
     * This instance is for the game timer
     */
    private Timer m_gameTimer;

    /**
     * This var makes an instance of the wall class
     */
    private final Wall m_wall;

    /**
     * This string is for the game message
     */
    private String m_message;

    /**
     * This boolean is for showing the pause menu
     */
    private boolean m_showPauseMenu;

    /**
     * This is for the menu font
     */
    private final Font m_menuFont;

    /**
     * This rectangle is for the continue button
     */
    private Rectangle m_continueButtonRect;

    /**
     * This rectangle is for the exit button
     */
    private Rectangle m_exitButtonRect;

    /**
     * This rectangle is the restart button
     */
    private Rectangle m_restartButtonRect;

    /**
     * This integer is for the string length
     */
    private int m_strLen;

    /**
     * This is for the DebugConsole
     */
    private final DebugConsole m_debugConsole;

    /**
     * The function for the game board
     *
     * @param owner owner passed through use of JFrame
     */
    public GameBoard(JFrame owner){
        super();

        m_strLen = 0;
        m_showPauseMenu = false;



        m_menuFont = new Font("Monospaced",Font.PLAIN, TEXT_SIZE);


        this.initialize();
        m_message = "Press SPACE to start";
        m_wall = new Wall(new Rectangle(0,0, DEF_WIDTH,DEF_HEIGHT),30,3, 3,new Point(300,430));

        m_debugConsole = new DebugConsole(owner, m_wall,this);
        //initialize the first level
        m_wall.nextLevel();

        m_gameTimer = new Timer(10, e ->{
            m_wall.move();
            m_wall.findImpacts();
            m_message = String.format("Bricks: %d Balls: %d Score: %d  HighScore: %s", m_wall.getM_brickCount(), m_wall.getM_ballCount(), m_wall.getM_scoreCount(), m_wall.getM_highScore());
            if(m_wall.isM_ballLost()){
                if(m_wall.ballEnd()){


                    //checks score for high score enter score if higher
                    m_wall.scoreCheck();
                    m_wall.wallReset();
                    m_message = "Game over Press Space Bar To Restart";
                }
                m_wall.ballReset();
                m_gameTimer.stop();
            }
            else if(m_wall.isDone()){
                if(m_wall.hasLevel()){

                    //shows score every round
                    m_message = String.format("Go to Next Level score so far is %d", m_wall.getM_scoreCount());

                    m_gameTimer.stop();
                    m_wall.ballReset();
                    m_wall.wallReset();
                    m_wall.nextLevel();

                }
                else{
                    m_wall.scoreCheck();
                    m_message = "ALL WALLS DESTROYED";
                    m_gameTimer.stop();
                }
            }

            repaint();
        });

    }


    /**
     * initialize the game board and GUI settings
     */
    public void initialize(){
        this.setPreferredSize(new Dimension(DEF_WIDTH,DEF_HEIGHT));
        this.setFocusable(true);
        this.requestFocusInWindow();
        this.addKeyListener(this);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }

    /**
     * function to paint the graphics
     * @param g graphics are passed though and uses g
     */
    public void paint(Graphics g){

        Graphics2D g2d = (Graphics2D) g;

        clear(g2d);

        g2d.setColor(Color.BLUE);
        g2d.drawString(m_message,250,225);

        drawBall(m_wall.ball,g2d);

        for(Brick b : m_wall.bricks)
            if(b.isM_broken())
                drawBrick(b,g2d);

        drawPlayer(m_wall.player,g2d);

        if(m_showPauseMenu)
            drawMenu(g2d);

        Toolkit.getDefaultToolkit().sync();

    }

    /**
     * clears the game board
     *
     * @param g2d uses g2d from 2d graphics class
     */
    public void clear(Graphics2D g2d){
        Color tmp = g2d.getColor();
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0,0,getWidth(),getHeight());
        g2d.setColor(tmp);
    }


    /**
     * This function draws a brick
     *
     * @param brick passes a brick from Brick class
     * @param g2d   passes g2d from Graphics2d class
     */
    public void drawBrick(Brick brick,Graphics2D g2d){
        Color tmp = g2d.getColor();

        g2d.setColor(brick.getInnerColor());
        g2d.fill(brick.getBrick());

        g2d.setColor(brick.getBorderColor());
        g2d.draw(brick.getBrick());


        g2d.setColor(tmp);
    }


    /**
     * This class draws a ball
     *
     * @param ball passes a ball from the blass class
     * @param g2d  passes g2d from the graphics2d class
     */
    public void drawBall(Ball ball, Graphics2D g2d){
        Color tmp = g2d.getColor();

        Shape s = ball.getM_ballFace();

        g2d.setColor(ball.getInnerColor());
        g2d.fill(s);

        g2d.setColor(ball.getBorderColor());
        g2d.draw(s);

        g2d.setColor(tmp);
    }

    /**
     * This class draws a player
     *
     * @param p   passes p from gamePaddle class
     * @param g2d passes g2d from Graphics2d class
     */
    public void drawPlayer(gamePaddle p, Graphics2D g2d){
        Color tmp = g2d.getColor();

        Shape s = p.getM_paddleFace();
        g2d.setColor(gamePaddle.INNER_COLOR);
        g2d.fill(s);

        g2d.setColor(gamePaddle.BORDER_COLOR);
        g2d.draw(s);

        g2d.setColor(tmp);
    }

    /**
     * This class draws the menu
     *
     * @param g2d passes the g2d parameter from Graphics2d
     */
    public void drawMenu(Graphics2D g2d){
        obscureGameBoard(g2d);
        drawPauseMenu(g2d);
    }

    /**
     * This class makes an obscure GameBoard
     *
     * @param g2d passes the g2d parameter from Graphics2d
     */
    public void obscureGameBoard(Graphics2D g2d){

        Composite tmp = g2d.getComposite();
        Color tmpColor = g2d.getColor();

        AlphaComposite ac = AlphaComposite.getInstance(AlphaComposite.SRC_OVER,0.55f);
        g2d.setComposite(ac);

        g2d.setColor(Color.BLACK);
        g2d.fillRect(0,0, DEF_WIDTH,DEF_HEIGHT);

        g2d.setComposite(tmp);
        g2d.setColor(tmpColor);
    }

    /**
     * This class draws a pause menu
     *
     * @param g2d passes the g2d from  Graphics2d
     */
    public void drawPauseMenu(Graphics2D g2d){
        Font tmpFont = g2d.getFont();
        Color tmpColor = g2d.getColor();


        g2d.setFont(m_menuFont);
        g2d.setColor(MENU_COLOR);

        if(m_strLen == 0){
            FontRenderContext frc = g2d.getFontRenderContext();
            m_strLen = m_menuFont.getStringBounds(PAUSE,frc).getBounds().width;
        }

        int x = (this.getWidth() - m_strLen) / 2;
        int y = this.getHeight() / 10;

        g2d.drawString(PAUSE,x,y);

        x = this.getWidth() / 8;
        y = this.getHeight() / 4;


        if(m_continueButtonRect == null){
            FontRenderContext frc = g2d.getFontRenderContext();
            m_continueButtonRect = m_menuFont.getStringBounds(CONTINUE,frc).getBounds();
            m_continueButtonRect.setLocation(x,y- m_continueButtonRect.height);
        }

        g2d.drawString(CONTINUE,x,y);

        y *= 2;

        if(m_restartButtonRect == null){
            m_restartButtonRect = (Rectangle) m_continueButtonRect.clone();
            m_restartButtonRect.setLocation(x,y- m_restartButtonRect.height);
        }
        g2d.drawString(RESTART,x,y);
        y *= 3.0/2;

        if(m_exitButtonRect == null){
            m_exitButtonRect = (Rectangle) m_continueButtonRect.clone();
            m_exitButtonRect.setLocation(x,y- m_exitButtonRect.height);
        }

        g2d.drawString(EXIT,x,y);



        g2d.setFont(tmpFont);
        g2d.setColor(tmpColor);
    }

    /**
     * This checks if the key is typed
     * @param keyEvent check the keyEvent from KeyEvent
     */
    @Override
    public void keyTyped(KeyEvent keyEvent) {
    }

    /**
     * This check is the key is pressed
     * @param e KeyEvent passes as e
     */
    @Override
    public void keyPressed(KeyEvent e) {
        int code=e.getKeyCode();

        // feature allows player to move paddle to the left
        if(code==KeyEvent.VK_LEFT){
            m_wall.player.moveLeft();
        }

        // feature allows player to move paddle to the right
        if(code==KeyEvent.VK_RIGHT){
            m_wall.player.movRight();
        }

        // feature allows player to show pause menu
        if(code==KeyEvent.VK_SPACE){
            if(!m_showPauseMenu)
                if(m_gameTimer.isRunning())
                    m_gameTimer.stop();
                else
                    m_gameTimer.start();
        }

        // allows the pause menu to be hidden
        if(code==KeyEvent.VK_ESCAPE){
            m_showPauseMenu = !m_showPauseMenu;
            repaint();
            m_gameTimer.stop();
        }
        if(code==KeyEvent.VK_F1){
            if(e.isAltDown() && e.isShiftDown())
                m_debugConsole.setVisible(true);
        }

        //added in a new button to change the levels
        if(code==KeyEvent.VK_L){
            m_wall.nextLevel();
        }
    }

    /**
     * This function is for the key when released
     * @param keyEvent passes keyEvent from KeyEvent
     */
    @Override
    public void keyReleased(KeyEvent keyEvent) {
        m_wall.player.stop();
    }

    /**
     * This function is for the mouse when clicked
     * @param mouseEvent passes mouseEvent from MouseEvent
     */
    @Override
    public void mouseClicked(MouseEvent mouseEvent) {
        Point p = mouseEvent.getPoint();
        if(!m_showPauseMenu)
            return;
        if(m_continueButtonRect.contains(p)){
            m_showPauseMenu = false;
            repaint();
        }
        else if(m_restartButtonRect.contains(p)){
            m_message = "Restarting Game...";
            m_wall.ballReset();
            m_wall.wallReset();
            m_showPauseMenu = false;
            repaint();
        }
        else if(m_exitButtonRect.contains(p)){
            //closes javafx first
            Platform.exit();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.exit(0);
        }

    }

    /**
     * This function for the mouse when pressed
     * @param mouseEvent passes mouseEvent from MouseEvent
     */
    @Override
    public void mousePressed(MouseEvent mouseEvent) {

    }

    /**
     * This function for the mouse when released
     * @param mouseEvent passes mouseEvent from MouseEvent
     */
    @Override
    public void mouseReleased(MouseEvent mouseEvent) {

    }

    /**
     * This function for the mouse when entered
     * @param mouseEvent passes mouseEvent from MouseEvent
     */
    @Override
    public void mouseEntered(MouseEvent mouseEvent) {

    }

    /**
     * This function for the mouse when exited
     * @param mouseEvent passes mouseEvent from MouseEvent
     */
    @Override
    public void mouseExited(MouseEvent mouseEvent) {

    }

    /**
     * This function for the mouse when dragged
     * @param mouseEvent passes mouseEvent from MouseEvent
     */
    @Override
    public void mouseDragged(MouseEvent mouseEvent) {

    }

    /**
     * This function for the mouse when moved
     * @param mouseEvent passes mouseEvent from MouseEvent
     */
    @Override
    public void mouseMoved(MouseEvent mouseEvent) {
        Point p = mouseEvent.getPoint();
        if(m_exitButtonRect != null && m_showPauseMenu) {
            if (m_exitButtonRect.contains(p) || m_continueButtonRect.contains(p) || m_restartButtonRect.contains(p))
                this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            else
                this.setCursor(Cursor.getDefaultCursor());
        }
        else{
            this.setCursor(Cursor.getDefaultCursor());
        }
    }

    /**
     * This function stop game on lost focus
     */
    public void onLostFocus(){
        m_gameTimer.stop();
        m_message = "Focus Lost";
        repaint();
    }



}
