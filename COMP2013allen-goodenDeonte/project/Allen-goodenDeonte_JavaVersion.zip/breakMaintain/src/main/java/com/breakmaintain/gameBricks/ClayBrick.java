package com.breakmaintain.gameBricks;

import java.awt.*;
import java.awt.Point;

/**
 * This class is for the clay brick
 *
 * @author Deonte Allen-Gooden-modified
 */
public class ClayBrick extends Brick {


    /**
     * Gives the brick an inner colour
     */
    private static final Color DEF_INNER = new Color(0, 0, 128).darker();

    /**
     * Gives the brick an outer colour
     */
    private static final Color DEF_BORDER = Color.GRAY;

    /**
     * Gives the brick a strength
     */
    private static final int CLAY_STRENGTH = 1;


    /**
     * This make the ClayBrick
     *
     * @param point point for the clay brick
     * @param size  size of the brick
     */
    public ClayBrick(Point point, Dimension size){
        super(point,size, DEF_BORDER, DEF_INNER, CLAY_STRENGTH);
    }

    /**
     * This makes a brick face for the clay brick
     * @param pos position point
     * @param size size of the brick
     * @return new rectangle
     */
    @Override
    protected Shape makeBrickFace(Point pos, Dimension size) {
        return new Rectangle(pos,size);
    }

    /**
     * This gets the brick
     * @return brick face
     */
    @Override
    public Shape getBrick() {
        return super.brickFace;
    }


}
