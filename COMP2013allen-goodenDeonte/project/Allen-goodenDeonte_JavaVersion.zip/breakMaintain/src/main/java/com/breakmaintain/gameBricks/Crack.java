package com.breakmaintain.gameBricks;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.io.File;

/**
 * This class is for the cracks in the brick
 */
public abstract class Crack extends Brick{

    private static final int CRACK_SECTIONS = 3;
    private static final double JUMP_PROBABILITY = 0.7;


    /**
     * Left integer set to 10
     */
    public static final int LEFT = 10;

    /**
     * Right integer set to 20
     */
    public static final int RIGHT = 20;

    /**
     * Up integer set to 30
     */
    public static final int UP = 30;

    /**
     * Down integer set to 40
     */
    public static final int DOWN = 40;

    /**
     * Vertical integer set to 100
     */
    public static final int VERTICAL = 100;

    /**
     * Horizontal integer set to 200
     */
    public static final int HORIZONTAL = 200;


    /**
     * Variable for the brick crack
     */
    private final GeneralPath m_crack;

    private final int m_crackDepth;
    private final int m_steps;
    private final Brick m_brick;

    /**
     * This function is for the crack in the brick
     *
     * @param brick      the brick
     * @param crackDepth How much of a crack will be in the brick
     * @param steps      steps passed as an integer
     */
    public Crack(Brick brick, int crackDepth, int steps){
        super();
        this.m_brick = brick;
        this.m_crackDepth = crackDepth;
        this.m_steps = steps;
        m_crack = new GeneralPath();


    }


    /**
     * This general path function uses draw
     *
     * @return a crack
     */
    public GeneralPath draw(){

        return m_crack;
    }

    /**
     * This resets the cracks
     */
    public void reset(){
        m_crack.reset();
    }


    /**
     * This makes the crack in the bricks
     *
     * @param point     point uses point 2d for point in the brick
     * @param direction the is for the direction integer
     */
    protected void makeCrack(Point2D point, int direction){
        Rectangle bounds = m_brick.brickFace.getBounds();

        Point impact = new Point((int)point.getX(),(int)point.getY());
        Point start = new Point();
        Point end = new Point();

        String path = "src\\main\\resources\\crack.mp3";
        Media media = new Media(new File(path).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        mediaPlayer.play();

        switch(direction){
            case LEFT:
                start.setLocation(bounds.x + bounds.width, bounds.y);
                end.setLocation(bounds.x + bounds.width, bounds.y + bounds.height);
                Point tmp = makeRandomPoint(start,end,VERTICAL);
                makeCrack(impact,tmp);

                break;
            case RIGHT:
                start.setLocation(bounds.getLocation());
                end.setLocation(bounds.x, bounds.y + bounds.height);
                tmp = makeRandomPoint(start,end,VERTICAL);
                makeCrack(impact,tmp);

                break;
            case UP:
                start.setLocation(bounds.x, bounds.y + bounds.height);
                end.setLocation(bounds.x + bounds.width, bounds.y + bounds.height);
                tmp = makeRandomPoint(start,end,HORIZONTAL);
                makeCrack(impact,tmp);
                break;
            case DOWN:
                start.setLocation(bounds.getLocation());
                end.setLocation(bounds.x + bounds.width, bounds.y);
                tmp = makeRandomPoint(start,end,HORIZONTAL);
                makeCrack(impact,tmp);

                break;

        }
    }

    /**
     * This makeCrack in brick
     *
     * @param start passes start point
     * @param end   passes end point
     */
    protected void makeCrack(Point start, Point end){

        GeneralPath path = new GeneralPath();


        path.moveTo(start.x,start.y);

        double w = (end.x - start.x) / (double) m_steps;
        double h = (end.y - start.y) / (double) m_steps;

        int bound = m_crackDepth;
        int jump  = bound * 5;

        double x,y;

        for(int i = 1; i < m_steps; i++){

            x = (i * w) + start.x;
            y = (i * h) + start.y + randomInBounds(bound);

            if(inMiddle(i, CRACK_SECTIONS, m_steps))
                y += jumps(jump, JUMP_PROBABILITY);

            path.lineTo(x,y);

        }

        path.lineTo(end.x,end.y);
        m_crack.append(path,true);
    }


    /**
     * This is for the random in bounds
     *
     * @param bound passes the int bounds
     * @return random next integer take away bounds
     */
    public int randomInBounds(int bound){
        int n = (bound * 2) + 1;
        return  getRnd().nextInt(n) - bound;
    }

    /**
     * This check if bricks and in the middle
     *
     * @param i         passes i integer
     * @param steps     passes steps integer
     * @param divisions passes divisions integer
     * @return returns the int greater than low and lower than high
     */
    public boolean inMiddle(int i,int steps,int divisions){
        int low = (steps / divisions);
        int up = low * (divisions - 1);

        return  (i > low) && (i < up);
    }

    /**
     * This is for the jumps
     *
     * @param bound       passes the integer bounds
     * @param probability pass the probability
     * @return returns 0
     */
    public int jumps(int bound,double probability){

        if(getRnd().nextDouble() > probability)
            return randomInBounds(bound);
        return  0;

    }

    /**
     * This makes a random point
     *
     * @param from      passes from point
     * @param to        passes to point
     * @param direction passes the direction integer
     * @return returns out
     */
    public Point makeRandomPoint(Point from,Point to, int direction){

        Point out = new Point();
        int pos;

        switch (direction) {
            case HORIZONTAL -> {
                pos = getRnd().nextInt(to.x - from.x) + from.x;
                out.setLocation(pos, to.y);
            }
            case VERTICAL -> {
                pos = getRnd().nextInt(to.y - from.y) + from.y;
                out.setLocation(to.x, pos);
            }
        }
        return out;
    }



}
