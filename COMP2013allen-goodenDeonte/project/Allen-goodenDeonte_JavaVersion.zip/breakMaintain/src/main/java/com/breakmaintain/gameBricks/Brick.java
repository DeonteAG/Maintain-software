package com.breakmaintain.gameBricks;

import com.breakmaintain.gameBall.Ball;

import com.breakmaintain.gameInterface.Wall;

import java.awt.*;
import java.awt.Point;
import java.awt.geom.Point2D;
import java.util.Random;

/**
 * This class is for the Bricks in the game
 *
 * @author Deonte Allen Gooden-modified
 */
abstract public class Brick {

    //public static final int MIN_CRACK = 1; both never used
    //public static final int MAX_CRACK = 3;

    /**
     * This is the int for the crack depth
     */
    public static final int DEF_CRACK_DEPTH = 1;

    /**
     * This is the int for steps
     */
    public static final int DEF_STEPS = 35;

    /**
     * This is the int for the impact moving up
     */
    public static final int UP_IMPACT = 100;

    /**
     * This is the int for the impact moving down
     */
    public static final int DOWN_IMPACT = 200;

    /**
     * This is the int for the impact moving left
     */
    public static final int LEFT_IMPACT = 300;

    /**
     * This is the int for the impact moving right
     */
    public static final int RIGHT_IMPACT = 400;


    /**
     * Gets rnd.
     *
     * @return the rnd
     */
    public static Random getRnd() {
        return rnd;
    }

    /**
     * for random integer
     */
    private static Random rnd;

    /**
     * The Brick face.
     */
    Shape brickFace;



    private Color m_border;
    private Color m_inner;
    private int m_fullStrength;
    private int m_strength;
    private boolean m_broken;

    /**
     * Gets wall.
     *
     * @return the wall
     */
    public Wall getWall() {
        return wall;
    }

    /**
     * Sets wall.
     *
     * @param wall the wall
     */
    public void setWall(Wall wall) {
        this.wall = wall;
    }

    private Wall wall;


    /**
     * class for the brick
     *
     * @param pos      point position
     * @param size     size of brick
     * @param border   brick border colour
     * @param inner    brick inner colour
     * @param strength brick strength
     */
    public Brick(Point pos, Dimension size, Color border, Color inner, int strength){
        rnd = new Random();
        m_broken = false;
        brickFace = makeBrickFace(pos,size);
        this.m_border = border;
        this.m_inner = inner;
        this.m_fullStrength = this.m_strength = strength;

    }


    /**
     * Instantiates a new Brick.
     */
    public Brick() {

    }

    /**
     * This makes the brick face
     *
     * @param pos  position point
     * @param size size of the brick
     * @return 0 shape
     */
    protected abstract Shape makeBrickFace(Point pos,Dimension size);

    /**
     * sets the impact of the ball
     *
     * @param point point of ball
     * @param dir   direction of ball
     * @return broken boolean
     */
    public  boolean setImpact(Point2D point , int dir){
        if(m_broken)
            return false;
        impact();
        return m_broken;
    }

    /**
     * gets brick
     *
     * @return 0 brick
     */
    public abstract Shape getBrick();

    /**
     * gets the border colour
     *
     * @return border colour
     */
    public Color getBorderColor(){
        return m_border;
    }

    /**
     * gets the inner colour
     *
     * @return inner colour
     */
    public Color getInnerColor(){
        return m_inner;
    }

    /**
     * finds the impact
     *
     * @param b passes ball parameter
     * @return out int
     */
    public final int findImpact(Ball b){
        if(m_broken)
            return 0;
        int out  = 0;
        if(brickFace.contains(b.right))
            out = LEFT_IMPACT;
        else if(brickFace.contains(b.left))
            out = RIGHT_IMPACT;
        else if(brickFace.contains(b.up))
            out = DOWN_IMPACT;
        else if(brickFace.contains(b.down))
            out = UP_IMPACT;
        return out;
    }

    /**
     * check is brick is broken
     *
     * @return nt broken
     */
    public final boolean isM_broken(){
        return !m_broken;
    }

    /**
     * repairs the brick
     */
    public void repair() {
        m_broken = false;
        m_strength = m_fullStrength;
    }

    /**
     * checks impact on brick
     */
    public void impact(){
        m_strength--;
        m_broken = (m_strength == 0);
    }



}





