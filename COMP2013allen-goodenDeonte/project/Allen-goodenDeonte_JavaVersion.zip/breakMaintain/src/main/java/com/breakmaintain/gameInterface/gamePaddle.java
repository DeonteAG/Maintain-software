package com.breakmaintain.gameInterface;

import com.breakmaintain.gameBall.Ball;

import java.awt.*;

/**
 * class for the game paddle
 *
 * @author Deonte Allen-Gooden-modified
 */
public class gamePaddle {

    /**
     * sets the border colour of the game paddle to blue
     */
    public static final Color BORDER_COLOR = Color.WHITE.darker().darker();

    /**
     * sets the inner colour to orange
     */
    public static final Color INNER_COLOR = Color.WHITE;


    /**
     * Increased the speed of the paddle to 10 as it was too slow once I increased the ball speed
     */
    public static final int DEF_MOVE_AMOUNT = 10;

    private final Rectangle m_paddleFace;
    private final Point m_ballPoint;
    private int m_moveAmount;
    private final int m_min;
    private final int m_max;

    /**
     * This is the function for the game paddle
     *
     * @param ballPoint ball point which uses the point class
     * @param width     integer of the width
     * @param height    integer of the height
     * @param container rectangle container for the paddle
     */
    public gamePaddle(Point ballPoint, int width, int height, Rectangle container) {
        this.m_ballPoint = ballPoint;
        m_moveAmount = 0;
        m_paddleFace = makeRectangle(width, height);
        m_min = container.x + (width / 2);
        m_max = m_min + container.width - width;

    }

    /**
     * This function makes a rectangle from Rectangle
     *
     * @param width  integer of the width
     * @param height integer of the height
     * @return a new rectangle
     */
    public Rectangle makeRectangle(int width,int height){
        Point p = new Point((int)(m_ballPoint.getX() - (width / 2)),(int) m_ballPoint.getY());
        return  new Rectangle(p,new Dimension(width,height));
    }

    /**
     * This boolean function is for the impact
     *
     * @param b passes through the ball as b
     * @return paddle face
     */
    public boolean impact(Ball b){
        return m_paddleFace.contains(b.getPosition()) && m_paddleFace.contains(b.down) ;
    }

    /**
     * This function is for the paddle movement
     */
    public void move(){
        double x = m_ballPoint.getX() + m_moveAmount;
        if(x < m_min || x > m_max)
            return;
        m_ballPoint.setLocation(x, m_ballPoint.getY());
        m_paddleFace.setLocation(m_ballPoint.x - (int) m_paddleFace.getWidth()/2, m_ballPoint.y);
    }

    /**
     * This function is for the left paddle movement
     */
    public void moveLeft(){
        m_moveAmount = -DEF_MOVE_AMOUNT;
    }

    /**
     * This function is for the right paddle movement
     */
    public void movRight(){
        m_moveAmount = DEF_MOVE_AMOUNT;
    }

    /**
     * This function stops the paddle
     */
    public void stop(){
        m_moveAmount = 0;
    }

    /**
     * This function gets the paddle face
     *
     * @return paddle face
     */
    public Shape getM_paddleFace(){
        return m_paddleFace;
    }

    /**
     * This function is for the move to point
     *
     * @param p passes point as p
     */
    public void moveTo(Point p){
        m_ballPoint.setLocation(p);
        m_paddleFace.setLocation(m_ballPoint.x - (int) m_paddleFace.getWidth()/2, m_ballPoint.y);
    }
}
