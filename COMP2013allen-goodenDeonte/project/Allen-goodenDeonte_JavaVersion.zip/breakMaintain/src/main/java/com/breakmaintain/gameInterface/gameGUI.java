package com.breakmaintain.gameInterface;

// import files needed in order for the game to run
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

/**
 * gameFrame class GUI for the main breakout game
 *
 * @author Deonte Allen-Gooden-modifed
 */
public class gameGUI extends JFrame implements WindowFocusListener {

    /**
     * This is for the title of the GUI
     */
    public static final String DEF_TITLE = "Breakout Game  Space = Start/Pause  left key and right key = Move Left/Right  ESC = Menu  New Level = L";

    /**
     * This is an instance of the game board
     */
    private final GameBoard m_gameBoard;

    /**
     * boolean called gaming set
     */
    private boolean m_gaming;

    /**
     * process to create a new frame of the game
     */
    public gameGUI(){
        super();
        m_gaming = false;
        this.setLayout(new BorderLayout());
        m_gameBoard = new GameBoard(this);
        this.add(m_gameBoard,BorderLayout.CENTER);
        initialize();
        this.addWindowFocusListener(this);
    }

    /**
     * void used to add visibility to the game title and other operations
     */
    public void initialize(){
        this.setTitle(DEF_TITLE);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.pack();
        this.autoLocate();
        this.setVisible(true);
    }

    /**
     * void used for the location of the frame and the height and the width
     */
    public void autoLocate(){
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (size.width - this.getWidth()) / 2;
        int y = (size.height - this.getHeight()) / 2;
        this.setLocation(x,y);
    }

    /**
     * This function is when the window gains focus
     * @param windowEvent passes the window event uses the WindowEvent class
     */
    @Override
    public void windowGainedFocus(WindowEvent windowEvent) {
        // the first time the frame loses focus is because it has been disposed to install the GameBoard, so went it regains the focus it's ready to play. of course calling a method such as 'onLostFocus' is useful only if the GameBoard as been displayed at least once
        m_gaming = true;
    }

    /**
     * This function is when the window loses focus
     * @param windowEvent passes the window event uses the WindowEvent class
     */
    @Override
    public void windowLostFocus(WindowEvent windowEvent) {
        if(m_gaming)
            m_gameBoard.onLostFocus();

    }
}
