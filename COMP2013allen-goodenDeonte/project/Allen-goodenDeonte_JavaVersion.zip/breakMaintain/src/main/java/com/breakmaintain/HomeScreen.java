package com.breakmaintain;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

/**
 * This is the main screen for the breakout game
 *
 * @author Deonte Allen-Gooden
 */
public class HomeScreen extends Application {
    /**
     * This is where the start of the game screen is
     * @param stage passes stage which is a stage type
     * @throws IOException if there is an error
     * @author Deonte Allen Gooden
     */
    @Override
    public void start(Stage stage) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource("hello-view.fxml")));
        stage.setTitle("Breakout Game!!");
        stage.setScene(new Scene( root,720, 480));
        stage.getIcons().add(new Image("homeScreen.png"));
        stage.show();


    }


    /**
     * The main function to launch the game
     *
     * @param args passes all the args
     */
    public static void main(String[] args) {
        launch(args);
    }
}