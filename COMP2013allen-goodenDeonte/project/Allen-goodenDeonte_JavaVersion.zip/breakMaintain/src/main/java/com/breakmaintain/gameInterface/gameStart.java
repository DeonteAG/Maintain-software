package com.breakmaintain.gameInterface;

import com.breakmaintain.HomeScreen;
import javafx.application.Application;

/**
 * This class is used to start the game
 * * @author Deonte Allen-Gooden-modified
 */
public class gameStart {

    /**
     * The main function for the game to start
     *
     * @param args passes through args
     */
    public static void main(String[] args){

        Application.launch(HomeScreen.class);
        //EventQueue.invokeLater(() -> new gameGUI().initialize());
    }


    // use [space] to start/pause the game
    // use [left key] to move the player left
    // use [right key] to move the player right
    // use [esc] to enter/exit pause menu
    // use [alt+shift+f1] at any time to display debug panel
}
