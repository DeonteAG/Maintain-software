package com.breakmaintain.gameBall;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.RectangularShape;


/**
 * This is the first class instance for a ball
 */
abstract public class Ball {


    private Shape m_ballFace;
    private final Point2D m_center;

    /**
     * Direction of the ball up
     */
    public Point2D up;

    /**
     * Direction of the ball down
     */
    public Point2D down;

    /**
     * Direction of the ball left
     */
    public Point2D left;

    /**
     * Direction of the ball right
     */
    public Point2D right;

    private final Color m_border;
    private final Color m_inner;
    //set a variable for the speed in the X direction
    private int m_speedX;
    //set a variable for the speed in the Y direction
    private int m_speedY;



    //function which sets an initialises the ball


    /**
     * Gets up.
     *
     * @return the up
     */
    public Point2D getUp() {
        return up;
    }

    /**
     * Sets up.
     *
     * @param up the up
     */
    public void setUp(Point2D up) {
        this.up = up;
    }

    /**
     * Gets down.
     *
     * @return the down
     */
    public Point2D getDown() {
        return down;
    }

    /**
     * Sets down.
     *
     * @param down the down
     */
    public void setDown(Point2D down) {
        this.down = down;
    }

    /**
     * Gets left.
     *
     * @return the left
     */
    public Point2D getLeft() {
        return left;
    }

    /**
     * Sets left.
     *
     * @param left the left
     */
    public void setLeft(Point2D left) {
        this.left = left;
    }

    /**
     * Gets right.
     *
     * @return the right
     */
    public Point2D getRight() {
        return right;
    }

    /**
     * Sets right.
     *
     * @param right the right
     */
    public void setRight(Point2D right) {
        this.right = right;
    }

    /**
     * Function for ball properties
     *
     * @param center  this is for the center of the ball uses Point2D
     * @param radiusA radiusA for ball uses integer
     * @param radiusB radiusB for ball uses integer
     * @param inner   inner colour of the ball
     * @param border  border colour of the ball
     */
    public Ball(Point2D center,int radiusA,int radiusB,Color inner,Color border){
        this.m_center = center;

        up = new Point2D.Double();
        down = new Point2D.Double();
        left = new Point2D.Double();
        right = new Point2D.Double();

        up.setLocation(center.getX(),center.getY()-(radiusB >> 1));
        down.setLocation(center.getX(),center.getY()+(radiusB >> 1));

        left.setLocation(center.getX()-(radiusA >> 1),center.getY());
        right.setLocation(center.getX()+(radiusA >> 1),center.getY());


        m_ballFace = makeBall(center,radiusA,radiusB);
        this.m_border = border;
        this.m_inner = inner;
        m_speedX = 0;
        m_speedY = 0;
    }

    /**
     * This makes the ball
     *
     * @param center  this is for the center of the ball uses Point2D
     * @param radiusA radiusA for ball uses integer
     * @param radiusB radiusB for ball uses integer
     * @return the ball shape
     */
    protected abstract Shape makeBall(Point2D center,int radiusA,int radiusB);

    /**
     * This moves the ball in the game
     */
    public void move(){
        RectangularShape tmp = (RectangularShape) m_ballFace;
        m_center.setLocation((m_center.getX() + m_speedX),(m_center.getY() + m_speedY));
        double w = tmp.getWidth();
        double h = tmp.getHeight();

        tmp.setFrame((m_center.getX() -(w / 2)),(m_center.getY() - (h / 2)),w,h);
        setPoints(w,h);


        m_ballFace = tmp;
    }

    /**
     * These sets speed for the ball
     *
     * @param x The x speed of the ball
     * @param y The y speed of the ball
     */
    public void setSpeed(int x,int y){
        m_speedX = x;
        m_speedY = y;
    }

    /**
     * This Sets the speed for x
     *
     * @param s Setting the speed for speed x
     */
    public void setXSpeed(int s){
        m_speedX = s;
    }

    /**
     * This Sets the speed for y
     *
     * @param s Setting the speed for speed y
     */
    public void setYSpeed(int s){
        m_speedY = s;
    }

    /**
     * Speed increases when the ball collides
     */
//increase speed reverse to game gets harder as collisions increase
    public void reverseX(){
        m_speedX *= -1.2;
    }

    //increase speed reverse to game gets harder as collisions increase

    /**
     * Increases speed once collision is made
     */
    public void reverseY(){
        m_speedY *= -1.2;
    }

    /**
     * This class get the border colour
     *
     * @return the border colour
     */
    public Color getBorderColor(){
        return m_border;
    }

    /**
     * This gets the inner colour for the ball
     *
     * @return the inner ball colour
     */
    public Color getInnerColor(){
        return m_inner;
    }

    /**
     * This gets the position of the ball
     *
     * @return the ball position
     */
    public Point2D getPosition(){
        return m_center;
    }

    /**
     * Gets the face of the ball
     *
     * @return returns the face of the ball
     */
    public Shape getM_ballFace(){
        return m_ballFace;
    }

    /**
     * This is for where ball is moving to
     *
     * @param p passes the point where ball moves to
     */
    public void moveTo(Point p){
        m_center.setLocation(p);

            //moveTo functions allows the ball to stay inside frame
        RectangularShape tmp = (RectangularShape) m_ballFace;
        double w = tmp.getWidth();
        double h = tmp.getHeight();

        tmp.setFrame((m_center.getX() -(w / 2)),(m_center.getY() - (h / 2)),w,h);


        m_ballFace = tmp;
    }

    /**
     * This sets the point for the ball
     *
     * @param width  passes the width of the point uses double
     * @param height passes the height of the point uses double
     */
    public void setPoints(double width,double height){
        up.setLocation(m_center.getX(), m_center.getY()-(height / 2));
        down.setLocation(m_center.getX(), m_center.getY()+(height / 2));

        left.setLocation(m_center.getX()-(width / 2), m_center.getY());
        right.setLocation(m_center.getX()+(width / 2), m_center.getY());
    }

    /**
     * Gets the speed of x
     *
     * @return Speed of x
     */
    public int getM_speedX(){
        return m_speedX;
    }

    /**
     * Gets the speed of y
     *
     * @return Speed of y
     */
    public int getM_speedY(){
        return m_speedY;
    }


}
