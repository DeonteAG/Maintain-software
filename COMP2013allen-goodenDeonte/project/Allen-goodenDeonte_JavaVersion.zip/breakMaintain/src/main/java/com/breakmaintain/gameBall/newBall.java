package com.breakmaintain.gameBall;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;


/**
 * Creates a new ball from the ball class
 */
public class newBall extends Ball {

    //commented out rubber ball never gets used
    //private static final String NAME = "Rubber Ball";

    /**
     * sets the radius to int 20
     */
    private static final int DEF_RADIUS = 10;

    /**
     * sets the inner colour of the ball
     */
    private static final Color DEF_INNER_COLOR = Color.WHITE;

    /**
     * set the border colour of the ball
     */
    private static final Color DEF_BORDER_COLOR = DEF_INNER_COLOR.darker().darker();

    /**
     * This makes the newBall
     *
     * @param center center point of the ball
     */
    public newBall(Point2D center){
        super(center, DEF_RADIUS, DEF_RADIUS, DEF_INNER_COLOR, DEF_BORDER_COLOR);
    }

    /**
     * This makes the ball
     * @param center this is for the center of the ball uses Point2D
     * @param radiusA radiusA for ball uses integer
     * @param radiusB radiusB for ball uses integer
     * @return new ball
     */
    @Override
    protected Shape makeBall(Point2D center, int radiusA, int radiusB) {

        //replace / with >>
        double x = center.getX() - (radiusA >> 1);
        double y = center.getY() - (radiusB >> 1);

        return new Ellipse2D.Double(x,y,radiusA,radiusB);
    }
}
