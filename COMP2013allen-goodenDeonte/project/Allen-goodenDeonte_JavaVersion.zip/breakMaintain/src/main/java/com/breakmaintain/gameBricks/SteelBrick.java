package com.breakmaintain.gameBricks;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.Random;

/**
 * This class is for the Steel brick
 *
 * @author Deonte Allen-Gooden-modified
 */
public class SteelBrick extends Brick {



    /**
     * Gives the brick an inner colour
     */
    private static final Color DEF_INNER = new Color(203, 203, 201);

    /**
     * Gives the brick an outer colour
     */
    private static final Color DEF_BORDER = Color.BLACK;

    /**
     * Give the brick a strength
     */
    private static final int STEEL_STRENGTH = 1;

    /**
     * Give brick probability
     */
    private static final double STEEL_PROBABILITY = 0.4;

    private final Random m_rnd;
    private final Shape m_brickFace;

    /**
     * Steel brick function
     *
     * @param point point of the brick
     * @param size  size of the brick
     */
    public SteelBrick(Point point, Dimension size){
        super(point,size, DEF_BORDER, DEF_INNER, STEEL_STRENGTH);
        m_rnd = new Random();
        m_brickFace = super.brickFace;
    }

    /**
     * This is the steel brick make face
     * @param pos position point
     * @param size size of the brick
     * @return rectangle
     */
    @Override
    protected Shape makeBrickFace(Point pos, Dimension size) {
        return new Rectangle(pos,size);
    }

    /**
     * This is the get brick function
     * @return brick face
     */
    @Override
    public Shape getBrick() {
        return m_brickFace;
    }

    /**
     * This is the brick impact set
     * @param point point of ball
     * @param dir direction of ball
     * @return false or not super.is broken
     */
    public  boolean setImpact(Point2D point , int dir){
        if(!super.isM_broken())
            return false;
        impact();
        return !super.isM_broken();
    }

    /**
     * This is for the brick impact
     */
    public void impact(){
        if(m_rnd.nextDouble() < STEEL_PROBABILITY){
            super.impact();
        }
    }

}