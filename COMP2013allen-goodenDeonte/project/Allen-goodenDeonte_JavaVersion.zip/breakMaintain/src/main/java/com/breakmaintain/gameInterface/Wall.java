package com.breakmaintain.gameInterface;

import com.breakmaintain.gameBall.Ball;
import com.breakmaintain.gameBall.newBall;
import com.breakmaintain.gameBricks.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.io.*;
import java.util.Random;


/**
 * This function is for the wall and collisions
 *
 * @author Deonte Allen-Gooden-modifed
 */
public class Wall {

    /**
     * counter for the amount of levels in the game
     */
    public static final int LEVELS_COUNT = 6;

    /**
     * initialise int for the clay
     */
    private static final int CLAY = 1;

    /**
     * initialise int for the Steel
     */
    private static final int STEEL = 2;

    /**
     * initialise int for the Cement
     */
    private static final int CEMENT = 3;

    


    /**
     * Get bricks brick [ ].
     *
     * @return the brick [ ]
     */
    public Brick[] getBricks() {
        return bricks;
    }

    /**
     * Sets bricks.
     *
     * @param bricks the bricks
     */
    public void setBricks(Brick[] bricks) {
        this.bricks = bricks;
    }

    /**
     * Gets ball.
     *
     * @return the ball
     */
    public Ball getBall() {
        return ball;
    }

    /**
     * Sets ball.
     *
     * @param ball the ball
     */
    public void setBall(Ball ball) {
        this.ball = ball;
    }

    
    private final Random m_rnd;
    private final Rectangle m_area;

    /**
     * The Bricks.
     */
    Brick[] bricks;

    /**
     * This is an instance of the ball from the ball class
     */
    public Ball ball;
    /**
     * The Player.
     */
    gamePaddle player;

    //array for the bricks for different levels
    private final Brick[][] m_levels;
    private int m_level;

    /**
     * get rid of the magic number 2
     */
    public static final int DOUBLE = 2;
    


    private final Point m_startPoint;
    private int m_brickCount;
    private int m_ballCount;
    private boolean m_ballLost;
    private int m_scoreCount;
    private String m_highScore = "";


    /**
     * Function for the wall
     *
     * @param drawArea            rectangle used to draw the area
     * @param brickCount          integer of the brick count passed
     * @param lineCount           integer of the line count passed
     * @param brickDimensionRatio double for the brick dimension ratio passed
     * @param ballPos             point used for the ball position
     * @author Deonte Allen-Gooden-modified
     */
    public Wall(Rectangle drawArea, int brickCount, int lineCount, double brickDimensionRatio, Point ballPos){

        this.m_startPoint = new Point(ballPos);

        m_levels = makeLevels(drawArea,brickCount,lineCount,brickDimensionRatio);
        m_level = 0;

        m_ballCount = 3;
        m_ballLost = false;

        m_scoreCount = 0;

        if(m_highScore.equals("")){
            m_highScore = this.getM_highScore();
        }

        this.m_rnd = new Random();

        makeBall(ballPos);
        int speedX,speedY;
        do{
            speedX = m_rnd.nextInt(5) - 2;
        }while(speedX == 0);
        do{
            speedY = -m_rnd.nextInt(3);
        }while(speedY == 0);

        ball.setSpeed(speedX,speedY);

        player = new gamePaddle((Point) ballPos.clone(),150,10, drawArea);

        m_area = drawArea;

        //Collisions col = new Collisions();


    }


    /**
     * This makes a single type of level
     *
     * @param drawArea       rectangle used to draw the area
     * @param brickCnt       integer of the brick count passed
     * @param lineCnt        integer of the line count passed
     * @param brickSizeRatio double for the brick dimension ratio passed
     * @param type           integer used to define the type of brick that is used
     * @return it will return tmp
     */
    public Brick[] makeSingleTypeLevel(Rectangle drawArea, int brickCnt, int lineCnt, double brickSizeRatio, int type){
        // if brickCount is not divisible by line count,brickCount is adjusted to the biggest multiple of lineCount smaller then brickCount
        brickCnt -= brickCnt % lineCnt;

        int brickOnLine = brickCnt / lineCnt;

        double brickLen = drawArea.getWidth() / brickOnLine;
        double brickHgt = brickLen / brickSizeRatio;

        brickCnt += lineCnt / 2;

        Brick[] tmp  = new Brick[brickCnt];

        Dimension brickSize = new Dimension((int) brickLen,(int) brickHgt);
        Point p = new Point();

        int i;
        for(i = 0; i < tmp.length; i++){
            int line = i / brickOnLine;
            if(line == lineCnt)
                break;
            double x = (i % brickOnLine) * brickLen;
            x =(line % DOUBLE == 0) ? x : (x - (brickLen / DOUBLE));
            double y = (line) * brickHgt;
            p.setLocation(x,y);
            tmp[i] = makeBrick(p,brickSize,type);
        }

        for(double y = brickHgt;i < tmp.length;i++, y += DOUBLE*brickHgt){
            double x = (brickOnLine * brickLen) - (brickLen / DOUBLE);
            p.setLocation(x,y);
            tmp[i] = new ClayBrick(p,brickSize);
        }
        return tmp;

    }

    /**
     * This function makes a chess board level
     *
     * @param drawArea       rectangle class and called draw area
     * @param brickCnt       integer passed through function for the brick count
     * @param lineCnt        integer passed through function for the line count
     * @param brickSizeRatio double passed through for brick size ratio
     * @param typeA          integer for the first type
     * @param typeB          integer for the second type
     * @return should return tmp
     */
    public Brick[] makeChessboardLevel(Rectangle drawArea, int brickCnt, int lineCnt, double brickSizeRatio, int typeA, int typeB){
        // if brickCount is not divisible by line count, brickCount is adjusted to the biggest multiple of lineCount smaller then brickCount
        brickCnt -= brickCnt % lineCnt;

        int brickOnLine = brickCnt / lineCnt;

        int centerLeft = brickOnLine / DOUBLE - 1;
        int centerRight = brickOnLine / DOUBLE + 1;

        double brickLen = drawArea.getWidth() / brickOnLine;
        double brickHgt = brickLen / brickSizeRatio;

        brickCnt += lineCnt / DOUBLE   ;

        Brick[] tmp  = new Brick[brickCnt];

        Dimension brickSize = new Dimension((int) brickLen,(int) brickHgt);
        Point p = new Point();

        int i;
        for(i = 0; i < tmp.length; i++){
            int line = i / brickOnLine;
            if(line == lineCnt)
                break;
            int posX = i % brickOnLine;
            double x = posX * brickLen;
            x =(line % DOUBLE == 0) ? x : (x - (brickLen / DOUBLE));
            double y = (line) * brickHgt;
            p.setLocation(x,y);

            boolean b =
                    ((line % DOUBLE == 0 && i % DOUBLE == 0) || (line % DOUBLE != 0 && posX > centerLeft && posX <= centerRight));
            tmp[i] = b ?  makeBrick(p,brickSize,typeA) : makeBrick(p,brickSize,typeB);
        }

        for(double y = brickHgt;i < tmp.length;i++, y += DOUBLE*brickHgt){
            double x = (brickOnLine * brickLen) - (brickLen / DOUBLE);
            p.setLocation(x,y);
            tmp[i] = makeBrick(p,brickSize,typeA);
        }
        return tmp;
    }

    /**
     * This function will make a ball
     *
     * @param ballPos point2d class for the ball position
     */
    public void makeBall(Point2D ballPos){
        ball = new newBall(ballPos);
    }

    /**
     * This function is used to makeLevels
     *
     * @param drawArea            rectangle used to draw area passed through
     * @param brickCount          int passed to show brick count
     * @param lineCount           int passed to show the lin count
     * @param brickDimensionRatio double passed for the brick dimension ratio
     * @return it will return tmp
     * @author Deonte Allen-Gooden-modified
     */
    public Brick[][] makeLevels(Rectangle drawArea,int brickCount,int lineCount,double brickDimensionRatio){
        Brick[][] tmp = new Brick[LEVELS_COUNT][];
        tmp[0] = makeSingleTypeLevel(drawArea,brickCount,lineCount,brickDimensionRatio, CLAY);
        tmp[1] = makeChessboardLevel(drawArea,brickCount,lineCount,brickDimensionRatio, CLAY, CEMENT);
        tmp[2] = makeChessboardLevel(drawArea,brickCount,lineCount,brickDimensionRatio, CLAY, STEEL);

        // New level to the game which have just Cement blocks in the code
        tmp[3] = makeChessboardLevel(drawArea,brickCount,lineCount,brickDimensionRatio, CEMENT, CEMENT);


        tmp[4] = makeChessboardLevel(drawArea,brickCount,lineCount,brickDimensionRatio, STEEL, CEMENT);

        // New final level which has just steel blocks on it
        tmp[5] = makeChessboardLevel(drawArea,brickCount,lineCount,brickDimensionRatio, STEEL, STEEL);

        return tmp;
    }

    /**
     * This function is for the move of the player and ball
     */
    public void move(){
        player.move();
        ball.move();
    }

    /**
     * This function checks the score to see if the high score has been beaten
     */
    public void scoreCheck(){
        if(m_scoreCount > Integer.parseInt(m_highScore.split(":")[1])){
            String enterName = JOptionPane.showInputDialog("New High Score!! Enter your name!");
            m_highScore = enterName + ":" + m_scoreCount;

            File scoreFile = new File("highscores.dat");
            if (!scoreFile.exists()) {
                try {
                    boolean newFile = scoreFile.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            FileWriter writeFile;
            BufferedWriter writer = null;

            try{
                writeFile = new FileWriter(scoreFile);
                writer = new BufferedWriter(writeFile);
                 writer.write(this.m_highScore);
            }
            catch (Exception ignored){

            }
            finally{
                if (writer != null) {
                    try {
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }


    /**
     * This function find the wall impact
     * added scoreCount+=10 to the else if command
     */
    public void findImpacts(){
        if(player.impact(ball)){
            ball.reverseY();
        }
        else if(impactWall()){
            // for efficiency reverse is done into method impactWall because for every brick program checks for horizontal and vertical impacts
            m_brickCount--;

            // added logic in for the score
            m_scoreCount +=10;
            String path = "src\\main\\resources\\coin.mp3";
            Media media = new Media(new File(path).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();

        }
        else if(impactBorder()) {
            ball.reverseX();
        }
        else if(ball.getPosition().getY() < m_area.getY()){
            ball.reverseY();
        }
        else if(ball.getPosition().getY() > m_area.getY() + m_area.getHeight()){
            m_ballCount--;
            m_ballLost = true;
        }

        // if a level is complete you get another ball
        else if (m_brickCount == 0){
            m_ballCount++;
        }

    }


    /**
     * This function boolean checks the wall impact
     *
     * @return different cases of ball impact
     */
    public boolean impactWall(){
        for(Brick b : bricks){
            switch (b.findImpact(ball)) {
                //Vertical Impact
                case Brick.UP_IMPACT -> {
                    ball.reverseY();
                    return b.setImpact(ball.down, Crack.UP);
                }
                case Brick.DOWN_IMPACT -> {
                    ball.reverseY();
                    return b.setImpact(ball.up, Crack.DOWN);
                }

                //Horizontal Impact
                case Brick.LEFT_IMPACT -> {
                    ball.reverseX();
                    return b.setImpact(ball.right, Crack.RIGHT);
                }
                case Brick.RIGHT_IMPACT -> {
                    ball.reverseX();
                    return b.setImpact(ball.left, Crack.LEFT);
                }
            }
        }
        return false;
    }

    /**
     * This function check the impact on the border
     *
     * @return the impact on border
     */
    public boolean impactBorder(){
        Point2D p = ball.getPosition();
        return ((p.getX() < m_area.getX()) ||(p.getX() > (m_area.getX() + m_area.getWidth())));
    }

    /**
     * This function gets the brick count
     *
     * @return the brick count
     */
    public int getM_brickCount(){
        return m_brickCount;
    }

    /**
     * This function gets the count of the score
     *
     * @return score count
     */
    public int getM_scoreCount(){return m_scoreCount;}

    /**
     * This function will get the high score
     *
     * @return high score
     */
    public String getM_highScore() {

        //format Deonte: 100
        FileReader fileread;
        BufferedReader reader = null;

        try {
            fileread = new FileReader("highscores.dat");
            reader = new BufferedReader(fileread);
            return reader.readLine();
        } catch (Exception e) {
            return "NoHighScore:0";
        }
        finally {
            try {
                if (reader !=null)
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * This function gets the ball count
     *
     * @return the ball count
     */
    public int getM_ballCount(){
        return m_ballCount;
    }

    /**
     * These functions check if the ball is lost
     *
     * @return return the ball lost
     */
    public boolean isM_ballLost(){
        return m_ballLost;
    }

    /**
     * This functions will reset the ball
     */
    public void ballReset(){
        player.moveTo(m_startPoint);
        ball.moveTo(m_startPoint);
        int speedX,speedY;
        do{
            speedX = m_rnd.nextInt(5) - DOUBLE;
        }while(speedX == 0);
        do{
            speedY = -m_rnd.nextInt(3);
        }while(speedY == 0);

        ball.setSpeed(speedX,speedY);
        m_ballLost = false;
    }

    /**
     * This functions resets the wall
     */
    public void wallReset(){
        for(Brick b : bricks)
            b.repair();
        m_brickCount = bricks.length;
        m_ballCount = 3;
        m_scoreCount = 0;
    }

    /**
     * This function checks if the amount of balls is done
     *
     * @return the ball count to zero
     */
    public boolean ballEnd(){
        return m_ballCount == 0;
    }

    /**
     * This function check if the level is done
     *
     * @return the brick count equal to zero
     */
    public boolean isDone(){
        return m_brickCount == 0;
    }

    /**
     * This function is for the next level to be put into place
     */
    public void nextLevel(){
        bricks = m_levels[m_level++];
        this.m_brickCount = bricks.length;
    }

    /**
     * checks if the game has a level
     *
     * @return level which is less than the level length
     */
    public boolean hasLevel(){
        return m_level < m_levels.length;
    }

    /**
     * This sets the ball speed for x
     *
     * @param s the integer for s is passed to set speed x
     */
    public void setBallXSpeed(int s){
        ball.setXSpeed(s);
    }


    /**
     * This sets the ball speed for y
     *
     * @param s the integer for s is passed to set speed y
     */
    public void setBallYSpeed(int s){
        ball.setYSpeed(s);
    }

    /**
     * This function resets the ball count
     */
    public void resetBallCount(){
        m_ballCount = 3;
    }

    /**
     * This function makes a brick
     *
     * @param point this makes a point from the point class
     * @param size  this indicates the size of the brick using the dimension class
     * @param type  this integer passed through as a type
     * @return switch type cases of either clay steel or cement
     * @author Deonte Allen-Gooden-modified
     */
    public Brick makeBrick(Point point, Dimension size, int type){
        return switch (type) {
            case CLAY -> new ClayBrick(point, size);
            case STEEL -> new SteelBrick(point, size);
            case CEMENT -> new CementBrick(point, size);
            default -> throw new IllegalArgumentException(String.format("Unknown Type:%d\n", type));
        };
    }

}
