package com.breakmaintain.fxControllers;

import com.breakmaintain.gameInterface.gameGUI;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Objects;


/**
 * This class is the controller of the breakout home screen
 *
 * @author Deonte Allen Gooden /
 */
public class HowToPlayController {

    /**
     * close button
     */
    @FXML public Button closeButton;

    /**
     * Quit button function
     *
     * @author Deonte Allen Gooden
     */
    @FXML
    public void OnQuitButtonClick(){
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
    }

    /**
     * start game function
     *
     * @author Deonte Allen Gooden
     */
    @FXML
    public void OnStartGameClick() {
        EventQueue.invokeLater(() -> new gameGUI().initialize());
    }

    /**
     * main menu button
     */
    @FXML
    public Button mainMenu;

    /**
     * Function for main button clicked
     *
     * @throws IOException in case an error occurs
     */
    @FXML
    public void OnMainButtonClick() throws IOException {
        Stage stage = (Stage) mainMenu.getScene().getWindow();
        Parent newRoot = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource("hello-view.fxml")));
        stage.setScene(new Scene(newRoot));
    }

    /**
     * The Path.
     */
    String path = "src\\main\\resources\\music.mp3";

    /**
     * The Media.
     */
    Media media = new Media(new File(path).toURI().toString());
    /**
     * The Media player.
     */
    MediaPlayer mediaPlayer = new MediaPlayer(media);

    /**
     * function for when the music button is clicked
     */
    public void OnMusicButtonOnClick() {
        mediaPlayer.play();
    }

    /**
     * function for when the music needs to be turned off
     */
    public void OnMusicButtonOffClick() {
        mediaPlayer.stop();
    }

}