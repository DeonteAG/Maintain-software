package com.breakmaintain.gameDebug;

import com.breakmaintain.gameBall.Ball;
import com.breakmaintain.gameInterface.GameBoard;
import com.breakmaintain.gameInterface.Wall;
import javafx.application.Platform;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/**
 * This class Debugs the console and is Using JDialog and Window Listener
 *
 * @author Deonte Allen Gooden-modified
 */
public class DebugConsole extends JDialog implements WindowListener{

    private static final String TITLE = "Debug Console";

    /**
     * This is the j frame instance called owner
     */
    private final JFrame m_owner;

    /**
     * This is an instance of the debug panel
     */
    private final DebugPanel m_debugPanel;

    /**
     * This is an instance of the game board
     */
    private final GameBoard m_gameBoard;

    /**
     * This is an instance of the wall called wall
     */
    private final Wall m_wall;

    /**
     * Instantiates a new Debug console.
     *
     * @param owner     frame parameter for the owner
     * @param wall      passes through the wall
     * @param gameBoard passes through the game board
     */
    public DebugConsole(JFrame owner,Wall wall,GameBoard gameBoard){

        this.m_wall = wall;
        this.m_owner = owner;
        this.m_gameBoard = gameBoard;
        initialize();

        m_debugPanel = new DebugPanel(wall);
        this.add(m_debugPanel,BorderLayout.CENTER);


        this.pack();
    }

    /**
     * The initialized state of the GUI
     */
    public void initialize(){
        this.setModal(true);
        this.setTitle(TITLE);
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.addWindowListener(this);
        this.setFocusable(true);
    }

    /**
     * The location of the window
     */
    public void setLocation(){
        int x = ((m_owner.getWidth() - this.getWidth()) / 2) + m_owner.getX();
        int y = ((m_owner.getHeight() - this.getHeight()) / 2) + m_owner.getY();
        this.setLocation(x,y);
    }

    /**
     *
     * @param windowEvent passes the window event from window event
     */
    @Override
    public void windowOpened(WindowEvent windowEvent) {

    }

    /**
     *
     * @param windowEvent passes the window event from window event
     */
    @Override
    public void windowClosing(WindowEvent windowEvent) {
        m_gameBoard.repaint();
    }

    /**
     *
     * @param windowEvent passes the window event from window event
     */
    @Override
    public void windowClosed(WindowEvent windowEvent) {
        Platform.exit();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(0);

    }

    /**
     *
     * @param windowEvent passes the window event from window event
     */
    @Override
    public void windowIconified(WindowEvent windowEvent) {

    }

    /**
     *
     * @param windowEvent passes the window event from window event
     */
    @Override
    public void windowDeiconified(WindowEvent windowEvent) {

    }

    /**
     *
     * @param windowEvent passes the window event from window event
     */
    @Override
    public void windowActivated(WindowEvent windowEvent) {
        setLocation();
        Ball b = m_wall.ball;
        m_debugPanel.setValues(b.getM_speedX(),b.getM_speedY());
    }

    /**
     *
     * @param windowEvent passes the window event from window event
     */
    @Override
    public void windowDeactivated(WindowEvent windowEvent) {

    }
}
