package com.breakmaintain.gameDebug;

import com.breakmaintain.gameInterface.Wall;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Debug Panel which extends jPanel
 */
public class DebugPanel extends JPanel {

    /**
     * set the background to white
     */
    private static final Color DEF_BKG = Color.WHITE;

    /**
     * This j slider is for the ball speed in the x direction
     */
    private JSlider m_ballXSpeed;

    /**
     * This j slider is for the ball speed in the y direction
     */
    private JSlider m_ballYSpeed;

    /**
     * This is the panel for the game
     *
     * @param wall this passes the wall from the Wall class
     */
    public DebugPanel(Wall wall){

        initialize();

        JButton skipLevel = makeButton("Skip Level", e -> wall.nextLevel());
        JButton resetBalls = makeButton("Reset Balls", e -> wall.resetBallCount());

        m_ballXSpeed = makeSlider(-4,4, e -> wall.setBallXSpeed(m_ballXSpeed.getValue()));
        m_ballYSpeed = makeSlider(-4,4, e -> wall.setBallYSpeed(m_ballYSpeed.getValue()));

        this.add(skipLevel);
        this.add(resetBalls);

        this.add(m_ballXSpeed);
        this.add(m_ballYSpeed);

    }

    /**
     * Function initializes background and grid
     */
    public void initialize(){
        this.setBackground(DEF_BKG);
        this.setLayout(new GridLayout(2,2));
    }

    /**
     * This makes a button for the game GUI
     *
     * @param title passes the game title as a string
     * @param e     passes an action listener as e
     * @return out j button
     */
    public JButton makeButton(String title, ActionListener e){
        JButton out = new JButton(title);
        out.addActionListener(e);
        return  out;
    }

    /**
     * This makes a slider for the game GUI
     *
     * @param min integer for the minimum
     * @param max integer for the maximum
     * @param e   change listener defined as e
     * @return out j slider
     */
    public JSlider makeSlider(int min, int max, ChangeListener e){
        JSlider out = new JSlider(min,max);
        out.setMajorTickSpacing(1);
        out.setSnapToTicks(true);
        out.setPaintTicks(true);
        out.addChangeListener(e);
        return out;
    }

    /**
     * Set values for the ball speed
     *
     * @param x integer for the ball speed in the x direction
     * @param y integer for the ball speed in the y direction
     */
    public void setValues(int x,int y){
        m_ballXSpeed.setValue(x);
        m_ballYSpeed.setValue(y);
    }

}
