package com.breakmaintain.gameBricks;

import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;

/**
 * This extends brick to make the cement brick
 *
 * @author Deonte Allen-Gooden-modified
 */
public class CementBrick extends Brick {

    /**
     * Gives the brick an inner colour
     */
    private static final Color DEF_INNER = new Color(147, 147, 147);

    /**
     * Gives the brick an outer colour
     */
    private static final Color DEF_BORDER = new Color(217, 199, 175);

    /**
     * Gives the brick strength a number
     */
    private static final int CEMENT_STRENGTH = 2;

    private final Crack m_crack;
    private Shape m_brickFace;

    /**
     * This is the cement brick class
     *
     * @param point point of the brick
     * @param size  size of the brick
     */
    public CementBrick(Point point, Dimension size){
        super(point,size, DEF_BORDER, DEF_INNER, CEMENT_STRENGTH);
        m_crack = new Crack(this, DEF_CRACK_DEPTH, DEF_STEPS) {
            @Override
            protected Shape makeBrickFace(Point pos, Dimension size) {
                return null;
            }

            @Override
            public Shape getBrick() {
                return null;
            }
        };
        m_brickFace = super.brickFace;
    }

    /**
     * The cement brick face
     * @param pos position point
     * @param size size of the brick
     * @return new rectangle
     */
    @Override
    protected Shape makeBrickFace(Point pos, Dimension size) {
        return new Rectangle(pos,size);
    }

    /**
     * The impact of the cement brick
     * @param point point of ball
     * @param dir direction of ball
     * @return true
     */
    @Override
    public boolean setImpact(Point2D point, int dir) {
        if(!super.isM_broken())
            return false;
        super.impact();
        if(super.isM_broken()){
            m_crack.makeCrack(point,dir);
            updateBrick();
            return false;
        }
        return true;
    }

    /**
     * gets the brick
     * @return brick face
     */
    @Override
    public Shape getBrick() {
        return m_brickFace;
    }

    /**
     * This updates the brick
     */
    private void updateBrick(){
        if(super.isM_broken()){
            GeneralPath gp = m_crack.draw();
            gp.append(super.brickFace,false);
            m_brickFace = gp;
        }
    }

    /**
     * repairs the brick
     */
    public void repair(){
        super.repair();
        m_crack.reset();
        m_brickFace = super.brickFace;
    }
}
