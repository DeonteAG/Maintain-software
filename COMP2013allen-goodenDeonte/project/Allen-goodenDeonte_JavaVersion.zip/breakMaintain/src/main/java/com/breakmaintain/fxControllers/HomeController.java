package com.breakmaintain.fxControllers;

import com.breakmaintain.gameInterface.GameBoard;
import com.breakmaintain.gameInterface.gameGUI;

import javafx.fxml.FXML;
import javafx.scene.control.ColorPicker;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Objects;


import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


/**
 * This class is the controller of the breakout home screen
 *
 * @author Deonte Allen Gooden /
 */
public class HomeController {

    /**
     * How Button declaration
     */
    @FXML
    public Button HowButton;

    /**
     * This is the function for the button to change to the HowToPlay Page
     *
     * @throws IOException Exception if error thrown
     */
    @FXML
    public void OnHowButtonClick()  throws IOException {
        Stage stage = (Stage) HowButton.getScene().getWindow();
        Parent newRoot = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource("how-view.fxml")));
        stage.setScene(new Scene(newRoot));

    }


    /**
     * close button
     */
    @FXML public Button closeButton;

    /**
     * Quit button function
     *
     * @author Deonte Allen Gooden
     */
    @FXML
    public void OnQuitButtonClick(){
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
    }

    /**
     * start game function
     *
     * @author Deonte Allen Gooden
     */
    @FXML
    public ColorPicker changeColour;

    /**
     * On start game click.
     */
    public void OnStartGameClick() {
        Color color = new Color((float) changeColour.getValue().getRed(),
        (float) changeColour.getValue().getGreen(),
        (float) changeColour.getValue().getBlue(),
        (float) changeColour.getValue().getOpacity());
        GameBoard.BG_COLOR = color;
        EventQueue.invokeLater(() -> new gameGUI().initialize());
    }

    /**
     * The Path.
     */
    String path = "src\\main\\resources\\music.mp3";
    /**
     * The Media.
     */
    Media media = new Media(new File(path).toURI().toString());
    /**
     * The Media player.
     */
    MediaPlayer mediaPlayer = new MediaPlayer(media);

    /**
     * function for when the music button is clicked
     */
    public void OnMusicButtonOnClick() {
        mediaPlayer.play();
    }

    /**
     * function for when the music needs to be turned off
     */
    public void OnMusicButtonOffClick() {
        mediaPlayer.stop();
    }
}