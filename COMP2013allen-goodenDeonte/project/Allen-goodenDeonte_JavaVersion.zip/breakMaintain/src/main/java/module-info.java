/**
 * This module is for the breakout maintenance
 */
module com.breakmaintain {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.datatransfer;
    requires java.desktop;
    requires javafx.media;





    exports com.breakmaintain;
    exports com.breakmaintain.fxControllers;
}