package com.breakmaintain.gameBall;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BallTest {

    @Test
    public void Ball() {
        int m_speedX, m_speedY;
        m_speedX = 0;
        m_speedY = 0;
        assertEquals(0,m_speedX);
        assertEquals(0,m_speedY);
    }

}