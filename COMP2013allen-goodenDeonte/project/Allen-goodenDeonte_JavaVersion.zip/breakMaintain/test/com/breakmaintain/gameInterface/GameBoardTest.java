package com.breakmaintain.gameInterface;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GameBoardTest {
    @Test
    public void GameBoard() {
        int m_strLen;
        m_strLen = 0;
        assertEquals(0,m_strLen);

    }

}