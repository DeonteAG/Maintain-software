package com.breakmaintain.gameInterface;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WallTest {

    @Test
    void wallReset() {
        int m_ballCount, m_scoreCount;
        m_ballCount = 3;
        m_scoreCount = 0;
        assertEquals(3,m_ballCount);
        assertEquals(0,m_scoreCount);
    }

    @Test
    void isDone() {
        int m_brickCount;
        m_brickCount = 0;
        assertEquals(0,m_brickCount);
    }

    @Test
    void ballEnd() {
        int m_ballCount;
        m_ballCount = 3;
        assertEquals(3,m_ballCount);
    }

    @Test
    void restBallCount() {
        int m_ballCount;
        m_ballCount = 3;
        assertEquals(3,m_ballCount);
    }


}